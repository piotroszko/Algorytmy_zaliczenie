﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SortowanieZliczanie
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> listaaa = new List<int>();
            listaaa.Add(5);
            listaaa.Add(5);
            listaaa.Add(1);
            listaaa.Add(4);
            listaaa.Add(2);
            listaaa.Add(4);
            Console.WriteLine("Lista nie posortowana: ");
            for (int i = 0; i < listaaa.Count; i++)
            {
                Console.Write("" + listaaa[i] +", ");
            }

            SortowanieZliczanie sortuj = new SortowanieZliczanie(listaaa);
            sortuj.Sortuj();
            Console.WriteLine("    ");
            Console.WriteLine("    ");
            Console.WriteLine("    ");

            Console.WriteLine("Lista posortowana: ");
            for (int i = 0; i < sortuj.poSortowana.Count; i++)
            {
                Console.Write("" + sortuj.poSortowana[i] + ", ");
            }

            Console.ReadKey();
        }
    }
    class SortowanieZliczanie
    {
        public List<int> poSortowana = new List<int>();
        List<int> doSortowania;
        int[] licznikWystapien;
        int n;

        public SortowanieZliczanie(List<int> doSortowania)
        {
            this.doSortowania = doSortowania;
            this.n = doSortowania.Max()+1;
            this.licznikWystapien = new int[n];
        }
        public void Sortuj ()
        {
            foreach (int i in doSortowania)
            {
                licznikWystapien[i]++;
            }
            for(int i = 0; i <n; i++)
            {
                for (int j = 0; j < licznikWystapien[i]; j++)
                {
                    this.poSortowana.Add(i);
                }
            }
        }
    }
}
