﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlgorytmPrim
{
    class Program
    {
        static void Main(string[] args)
        {

            // przykladowe drzewo to to http://www.algorytm.org/images/grafy/prim1.gif

            List<Krawedz> k = new List<Krawedz>();
            List<Node> n = new List<Node>();
            n.Add(new Node("a"));//0
            n.Add(new Node("b"));//1
            n.Add(new Node("c"));//2
            n.Add(new Node("e"));//3
            n.Add(new Node("f"));//4
            n.Add(new Node("d"));//5

            k.Add(new Krawedz(4,n[0],n[1])); //ab
            k.Add(new Krawedz(2, n[1], n[2])); //bc
            k.Add(new Krawedz(2, n[0], n[4])); //af
            k.Add(new Krawedz(1, n[0], n[3])); //ae
            k.Add(new Krawedz(2, n[1], n[3])); // be
            k.Add(new Krawedz(8, n[2], n[5])); //cd
            k.Add(new Krawedz(7, n[3], n[4])); //ef
            k.Add(new Krawedz(3, n[3], n[5])); //ed
            k.Add(new Krawedz(6, n[4], n[5])); //fd

            Prim p = new Prim(n,k);
            p.ZnajdzDrzewo(n[0]);
            Console.WriteLine(" Drzewo nody: ");
            foreach (Node ni in p.listaNodeDrzewo)
            {
                Console.Write(ni.nazwa + ", ");
            }
            Console.WriteLine("  ");
            Console.WriteLine(" Krawedzie drzewa: ");
            foreach (Krawedz ki in p.listaKrawedzDrzewo)
            {
                Console.WriteLine("- Node1:" + ki.node1.nazwa + " , Node2:" + ki.node2.nazwa + " ,wartosc:" + ki.waga);
            }
            Console.ReadKey();
        }
    }
    class Node
    {
        public string nazwa;

        public Node(string nazwa)
        {
            this.nazwa = nazwa;
        }
    }
    class Krawedz
    {
        public int waga;
        public Node node1;
        public Node node2;

        public Krawedz(int waga, Node node1, Node node2)
        {
            this.waga = waga;
            this.node1 = node1;
            this.node2 = node2;
        }

    }
    class Prim
    {
        public List<Node> listaNode = new List<Node>();
        public List<Krawedz> listaKrawedz = new List<Krawedz>();

        // tu bedzie koncowy wynik algorytmu
        public List<Node> listaNodeDrzewo = new List<Node>();
        public List<Krawedz> listaKrawedzDrzewo = new List<Krawedz>();

        public Prim(List<Node> listaNode, List<Krawedz> listaKrawedz)
        {
            this.listaNode = listaNode;
            this.listaKrawedz = listaKrawedz;
        }

        public void ZnajdzDrzewo(Node startowy)
        {
            List<Krawedz> tmpKrawedzie = new List<Krawedz>();
            listaNodeDrzewo.Add(startowy);
            tmpKrawedzie = listaPoprawnaKrawedzi();

            while (listaNodeDrzewo.Count < listaNode.Count)
            {
                var najmniejszy = from s in tmpKrawedzie orderby s.waga ascending select s;

                if (tmpKrawedzie.Count == 0) break;
                listaKrawedzDrzewo.Add(najmniejszy.First());
                listaNodeDrzewo.Add(zwrocNieistniejacy(najmniejszy.First()));
                tmpKrawedzie.Clear();
                tmpKrawedzie = listaPoprawnaKrawedzi();
            }

        }
        List<Krawedz>  listaPoprawnaKrawedzi ()
        {
            List<Krawedz> tmp = new List<Krawedz>();
            List<Krawedz> kList = new List<Krawedz>();

            foreach(Node n in this.listaNodeDrzewo)
            {
                tmp.Clear();
                tmp = zwrocKrawedzie(n);
                foreach (Krawedz tmpK in tmp)
                {
                    if (!(this.listaNodeDrzewo.Contains(tmpK.node1)))
                    {
                        if (this.listaNodeDrzewo.Contains(tmpK.node2)) kList.Add(tmpK);
                    }
                    else if (this.listaNodeDrzewo.Contains(tmpK.node1))
                    {
                        if (!(this.listaNodeDrzewo.Contains(tmpK.node2)))  kList.Add(tmpK);
                    }
                }

            }
            return kList;
        }
        Node zwrocNieistniejacy(Krawedz k)
        {
            if (this.listaNodeDrzewo.Contains(k.node1))
            {
                return k.node2;
            } else return k.node1;

        }


        Node zwrocDrugi (Node n,Krawedz k)
        {
            if (k.node1 == n)
            {
                return k.node2;
            } else return k.node1;
        }
        List<Krawedz> zwrocKrawedzie(Node nTmp)
        {
            List<Krawedz> kList = new List<Krawedz>();
            foreach (Krawedz k in listaKrawedz)
            {
                if (k.node1 == nTmp || k.node2 == nTmp)
                {
                    kList.Add(k);
                }
            }
            return kList;
        }
    }
}
