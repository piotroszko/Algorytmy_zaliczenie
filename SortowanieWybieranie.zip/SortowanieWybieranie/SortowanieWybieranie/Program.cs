﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SortowanieWybieranie
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> doSortowania = new List<int>();
            doSortowania.Add(9);
            doSortowania.Add(1);
            doSortowania.Add(6);
            doSortowania.Add(8);
            doSortowania.Add(4);
            doSortowania.Add(3);
            doSortowania.Add(2);
            doSortowania.Add(0);
            SortowanieWybieranie sortuj = new SortowanieWybieranie(doSortowania);
            for (int i = 0; i < doSortowania.Count; i++)
            {
                Console.WriteLine("-: " + doSortowania[i]);
            }
            Console.WriteLine(" - ");
            Console.WriteLine(" - ");
            Console.WriteLine(" - ");
            Console.WriteLine(" - ");
            Console.WriteLine(" - ");
            sortuj.Sortuj();
            for (int i = 0; i < sortuj.doSortowanie.Count; i++)
            {
                Console.WriteLine("-: " + sortuj.doSortowanie[i]);
            }
            Console.ReadKey();
        }
    }
    class SortowanieWybieranie
    {
        public List<int> doSortowanie = new List<int>();

        public SortowanieWybieranie(List<int> doSortowanie)
        {
            this.doSortowanie = doSortowanie;
        }
        public void Sortuj ()
        {
            int n = doSortowanie.Count;
            for (int i = 0; i < n; i++)
            {
                if (doSortowanie[i] != i)
                {
                    int minWart = doSortowanie[i];
                    int indexMinWart = i;

                    int wartZamieniana = doSortowanie[i];
                    int indexZamienianej = i;

                    bool czyJestInnaWartosc = false;
                    for (int j = i; j < n; j++)
                    {
                        if (doSortowanie[j] < minWart)
                        {
                            minWart = doSortowanie[j];
                            indexMinWart = j;
                            czyJestInnaWartosc = true;
                        }
                    }
                    if (czyJestInnaWartosc)
                    {
                        doSortowanie.RemoveAt(indexMinWart);
                        doSortowanie.RemoveAt(indexZamienianej);

                        doSortowanie.Insert(indexZamienianej, minWart);
                        doSortowanie.Insert(indexMinWart, wartZamieniana);
                    }
                }
            }
        }
    }
}
