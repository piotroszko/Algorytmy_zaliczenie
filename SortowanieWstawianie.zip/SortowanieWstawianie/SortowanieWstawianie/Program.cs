﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SortowanieWstawianie
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> doSortowania = new List<int>();
            doSortowania.Add(6);
            doSortowania.Add(5);
            doSortowania.Add(3);
            doSortowania.Add(1);
            doSortowania.Add(8);
            doSortowania.Add(7);
            doSortowania.Add(2);
            doSortowania.Add(4);
            SortowanieWstawianie sortuj = new SortowanieWstawianie(doSortowania);
            for (int i = 0; i < sortuj.listaLiczb.Count; i++)
            {
                Console.WriteLine(sortuj.listaLiczb[i]);
            }
            Console.WriteLine(" _ ");
            Console.WriteLine(" _ ");
            Console.WriteLine(" _ ");
            Console.WriteLine(" _ ");
            sortuj.Sortuj();
            for (int i = 0; i < sortuj.listaLiczb.Count; i++)
            {
                Console.WriteLine(sortuj.listaLiczb[i]);
            }
            Console.ReadKey();
        }
    }
    class SortowanieWstawianie
    {
        public List<int> listaLiczb = new List<int>();

        public SortowanieWstawianie(List<int> listaLiczb)
        {
            this.listaLiczb = listaLiczb;
        }
        public void Sortuj()
        {
            int n = listaLiczb.Count;
            for (int i = 1; i<n; i++)
            {
                int tmpA = listaLiczb[i];
                bool tmpBool = false;
                for (int j=i - 1; j>= 0 && tmpBool != true; )
                {
                    if (tmpA < listaLiczb[j])
                    {
                        listaLiczb[j + 1] = listaLiczb[j];
                        j--;
                        listaLiczb[j + 1] = tmpA;
                    } else { tmpBool = true; }
                }

            }
        }
    }
}
