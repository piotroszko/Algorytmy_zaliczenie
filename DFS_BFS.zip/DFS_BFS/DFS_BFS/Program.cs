﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace DFS_BFS
{
    class Program
    {
        static void Main(string[] args)
        {
            /*         0
             *       1   2 
             *     3  4
             * 
             * 
             * */
            Node korzen = new Node("0");
            Node punkt1 = new Node("1");
            Node punkt2 = new Node("2");
            Node punkt3 = new Node("3");
            Node punkt4 = new Node("4");

            korzen.Lewe = punkt1;
            korzen.Prawe = punkt2;

            punkt1.Lewe = punkt3;
            punkt1.Prawe = punkt4;

            DepthFirstSearch dfs = new DepthFirstSearch(korzen);
            BreadthFirstSearch bfs = new BreadthFirstSearch(korzen);
            Console.WriteLine(dfs.Search("2"));
            Console.WriteLine(bfs.Search("5"));

            Console.ReadKey();
        }
    }
    public class Node
    {
        public Node(string nazwa)
        {
            Lewe = null;
            Prawe = null;
            this.nazwa = nazwa;
        }
        public Node(Node lewe, Node prawe, string nazwa)
        {
            Lewe = lewe;
            Prawe = prawe;
            this.nazwa = nazwa;
        }

        public Node Lewe { get; set; }
        public Node Prawe { get; set; }
        public string nazwa { get; set; }

        public override string ToString()
        {
            return " Nazwa: " + nazwa + " Lewe:" + Lewe + " Prawe:" + Prawe;
        }
    }
    public class DepthFirstSearch
    {
        public List<Node> kolejkaWyszukiwan;
        private Node korzen;
        public DepthFirstSearch(Node nodeKorzenia)
        {
            korzen = nodeKorzenia;
            kolejkaWyszukiwan = new List<Node>();
        }
        public bool Search(string szukanyNode)
        {
            Node aktualny;
            kolejkaWyszukiwan.Add(korzen);
            while (kolejkaWyszukiwan.Count != 0)
            {
                //
                aktualny = kolejkaWyszukiwan.Last();
                kolejkaWyszukiwan.RemoveAt(kolejkaWyszukiwan.Count() - 1);
                // tutaj znajduje sie roznica miedzy bfs i dfs
                if (aktualny != null & aktualny.nazwa == szukanyNode)
                {
                    return true;
                }
                else
                {
                    if (aktualny.Prawe != null) kolejkaWyszukiwan.Add(aktualny.Prawe);
                    if (aktualny.Lewe != null) kolejkaWyszukiwan.Add(aktualny.Lewe);
                }
            }
            return false;
        }
    }
    public class BreadthFirstSearch
    {
        public List<Node> kolejkaWyszukiwan;
        private Node korzen;
        public BreadthFirstSearch(Node nodeKorzenia)
        {
            korzen = nodeKorzenia;
            kolejkaWyszukiwan = new List<Node>();
        }
        public bool Search(string szukanyNode)
        {
            Node aktualny;
            kolejkaWyszukiwan.Add(korzen); 
            while (kolejkaWyszukiwan.Count != 0)
            {
                //
                aktualny = kolejkaWyszukiwan.First();
                kolejkaWyszukiwan.RemoveAt(0);

                // tutaj znajduje sie roznica miedzy bfs i dfs
                // dfs przeszukuje kazde rozwiedlenie w dal (w przypadku tego grafu, po odkryciu Node=1 przeszukuje w glab tego noda,
                //gdzie bfs po sprawdzeniu Node=1, przeszukuje Node=2)
                if (aktualny != null & aktualny.nazwa == szukanyNode)
                {
                    return true;
                }
                else
                {
                    if (aktualny.Prawe != null) kolejkaWyszukiwan.Add(aktualny.Prawe);
                    if (aktualny.Lewe != null) kolejkaWyszukiwan.Add(aktualny.Lewe);
                }
            }
            return false;
        }
    }

}
