﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Fibb_NWD_Sortowanie
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btFibb_Click(object sender, EventArgs e)
        {
            int txtTmp = Int32.Parse(txtFibbN.Text);
            int m = 0;
            int m0 = 0;
            int m1 = 1;
            for (int i = 0; i < txtTmp -1 ; i++) {
                int tmp = m;
                m = m1 + m0;
                m0 = m1;
                m1 = m;
            }
            lbWynikFibb.Text = m.ToString();

        }
        int NWD(int a, int b) {
            int t = a % b;
            if (t == 0) {
                return b;
            }
            return NWD(b, t);

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void btNWD_Click(object sender, EventArgs e)
        {
            int NWD1 = Int32.Parse(txtNWD1.Text);
            int NWD2 = Int32.Parse(txtNWD2.Text);
            int wynikNWD = NWD(NWD1, NWD2);
            lbWynikNWD.Text = wynikNWD.ToString();
        }
    }
}
