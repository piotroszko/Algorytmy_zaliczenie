﻿namespace Fibb_NWD_Sortowanie
{
    partial class Form1
    {
        /// <summary>
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod generowany przez Projektanta formularzy systemu Windows

        /// <summary>
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            this.btFibb = new System.Windows.Forms.Button();
            this.txtFibbN = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lbWynikFibb = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtNWD1 = new System.Windows.Forms.TextBox();
            this.txtNWD2 = new System.Windows.Forms.TextBox();
            this.btNWD = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.lbWynikNWD = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btFibb
            // 
            this.btFibb.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btFibb.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btFibb.Location = new System.Drawing.Point(178, 33);
            this.btFibb.Name = "btFibb";
            this.btFibb.Size = new System.Drawing.Size(102, 57);
            this.btFibb.TabIndex = 0;
            this.btFibb.Text = "Generuj";
            this.btFibb.UseVisualStyleBackColor = true;
            this.btFibb.Click += new System.EventHandler(this.btFibb_Click);
            // 
            // txtFibbN
            // 
            this.txtFibbN.Location = new System.Drawing.Point(72, 44);
            this.txtFibbN.Name = "txtFibbN";
            this.txtFibbN.Size = new System.Drawing.Size(100, 20);
            this.txtFibbN.TabIndex = 1;
            this.txtFibbN.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(20, 47);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(46, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Podaj n:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(175, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(40, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Wynik:";
            // 
            // lbWynikFibb
            // 
            this.lbWynikFibb.AutoSize = true;
            this.lbWynikFibb.Location = new System.Drawing.Point(222, 9);
            this.lbWynikFibb.Name = "lbWynikFibb";
            this.lbWynikFibb.Size = new System.Drawing.Size(13, 13);
            this.lbWynikFibb.TabIndex = 4;
            this.lbWynikFibb.Text = "0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(23, 8);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Fibbonaci";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(349, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(34, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "NWD";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(352, 50);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(16, 13);
            this.label5.TabIndex = 7;
            this.label5.Text = "a:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(496, 50);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(16, 13);
            this.label6.TabIndex = 8;
            this.label6.Text = "b:";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // txtNWD1
            // 
            this.txtNWD1.Location = new System.Drawing.Point(374, 47);
            this.txtNWD1.Name = "txtNWD1";
            this.txtNWD1.Size = new System.Drawing.Size(100, 20);
            this.txtNWD1.TabIndex = 9;
            // 
            // txtNWD2
            // 
            this.txtNWD2.Location = new System.Drawing.Point(518, 47);
            this.txtNWD2.Name = "txtNWD2";
            this.txtNWD2.Size = new System.Drawing.Size(100, 20);
            this.txtNWD2.TabIndex = 10;
            // 
            // btNWD
            // 
            this.btNWD.Location = new System.Drawing.Point(457, 12);
            this.btNWD.Name = "btNWD";
            this.btNWD.Size = new System.Drawing.Size(75, 23);
            this.btNWD.TabIndex = 11;
            this.btNWD.Text = "Generuj";
            this.btNWD.UseVisualStyleBackColor = true;
            this.btNWD.Click += new System.EventHandler(this.btNWD_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(560, 17);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(70, 13);
            this.label7.TabIndex = 12;
            this.label7.Text = "Wynik NWD:";
            // 
            // lbWynikNWD
            // 
            this.lbWynikNWD.AutoSize = true;
            this.lbWynikNWD.Location = new System.Drawing.Point(637, 17);
            this.lbWynikNWD.Name = "lbWynikNWD";
            this.lbWynikNWD.Size = new System.Drawing.Size(13, 13);
            this.lbWynikNWD.TabIndex = 13;
            this.lbWynikNWD.Text = "0";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(732, 111);
            this.Controls.Add(this.lbWynikNWD);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.btNWD);
            this.Controls.Add(this.txtNWD2);
            this.Controls.Add(this.txtNWD1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lbWynikFibb);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtFibbN);
            this.Controls.Add(this.btFibb);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btFibb;
        private System.Windows.Forms.TextBox txtFibbN;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lbWynikFibb;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtNWD1;
        private System.Windows.Forms.TextBox txtNWD2;
        private System.Windows.Forms.Button btNWD;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lbWynikNWD;
    }
}

