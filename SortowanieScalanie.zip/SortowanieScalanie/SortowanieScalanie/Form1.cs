﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SortowanieScalanie
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        
        int[] Konwertuj(string cyfry)
        {
            var wynikS = cyfry.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

            int[] wynik = new int[wynikS.Length];
            for (int i = 0; i < wynikS.Length; i++)
            {
                wynik[i] = int.Parse(wynikS[i].Trim());
            }

            return wynik;
        }

        private void btSortuj_Click(object sender, EventArgs e)
        {
            int[] tablica = Konwertuj(txtSortowanieWejscie.Text);
            SortowaniePrzezScalanie posortuj = new SortowaniePrzezScalanie(tablica);
            posortuj.Sortowanie(posortuj.poczatekTablicy,posortuj.koniecTablicy);
            lbWynikScalania.Text = string.Join(",", posortuj.tablica.ToArray());
        }
        
    }
    class SortowaniePrzezScalanie {
        public int[] tablica;
        public int[] tablicaPomocznica;
        public int n = 0;
        public int poczatekTablicy = 0;
        public int koniecTablicy = 0;

        public SortowaniePrzezScalanie(int[] tablica)
        {
            this.tablica = tablica;
            this.n = tablica.Length;
            this.poczatekTablicy = 0;
            this.koniecTablicy = n - 1;
            this.tablicaPomocznica = new int[n];
        }
        void Scalanie(int poczatek, int koniec)
        {
            this.tablicaPomocznica = this.tablica;
            int p = poczatek;
            int r = poczatek;
            int q = (poczatek + koniec) / 2 + 1;
            while (p <= (poczatek + koniec) / 2 && q <= koniec) {
                if (tablicaPomocznica[p] < tablicaPomocznica[q]) {
                    this.tablica[r] = this.tablicaPomocznica[p];
                    p++;
                    r++;
                }
                else
                {
                    this.tablica[r] = this.tablicaPomocznica[q];
                    r++;
                    q++;
                }

            }
            while (p <= (poczatek + koniec) / 2)
            {
                this.tablica[r] = this.tablicaPomocznica[p];
                r++;
                p++;
            }
        }
        public void Sortowanie(int poczatek, int koniec)
        {
            if (poczatek < koniec) {
                Sortowanie(poczatek, (poczatek + koniec) / 2);
                Sortowanie((poczatek + koniec) / 2 + 1, koniec);
                Scalanie(poczatek, koniec);
            }
        }
    }
}
