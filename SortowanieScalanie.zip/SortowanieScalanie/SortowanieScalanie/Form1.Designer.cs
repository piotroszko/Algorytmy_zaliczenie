﻿namespace SortowanieScalanie
{
    partial class Form1
    {
        /// <summary>
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod generowany przez Projektanta formularzy systemu Windows

        /// <summary>
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtSortowanieWejscie = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btSortuj = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.lbWynikScalania = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtSortowanieWejscie
            // 
            this.txtSortowanieWejscie.Location = new System.Drawing.Point(169, 12);
            this.txtSortowanieWejscie.Name = "txtSortowanieWejscie";
            this.txtSortowanieWejscie.Size = new System.Drawing.Size(100, 20);
            this.txtSortowanieWejscie.TabIndex = 0;
            this.txtSortowanieWejscie.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(33, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(130, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Sortowanie przez scalanie";
            // 
            // btSortuj
            // 
            this.btSortuj.Location = new System.Drawing.Point(295, 12);
            this.btSortuj.Name = "btSortuj";
            this.btSortuj.Size = new System.Drawing.Size(75, 23);
            this.btSortuj.TabIndex = 2;
            this.btSortuj.Text = "Sortuj";
            this.btSortuj.UseVisualStyleBackColor = true;
            this.btSortuj.Click += new System.EventHandler(this.btSortuj_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(166, 55);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Wynik scalania:";
            // 
            // lbWynikScalania
            // 
            this.lbWynikScalania.AutoSize = true;
            this.lbWynikScalania.Location = new System.Drawing.Point(268, 55);
            this.lbWynikScalania.Name = "lbWynikScalania";
            this.lbWynikScalania.Size = new System.Drawing.Size(13, 13);
            this.lbWynikScalania.TabIndex = 4;
            this.lbWynikScalania.Text = "0";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(517, 156);
            this.Controls.Add(this.lbWynikScalania);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btSortuj);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtSortowanieWejscie);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtSortowanieWejscie;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btSortuj;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lbWynikScalania;
    }
}

