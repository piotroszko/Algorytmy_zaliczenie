﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kolejka_Stos
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
    class Kolejka : IAisd
    {
        public List<int> lista;

        public Kolejka(int wartosc)
        {
            this.lista = new List<int>();
            Push(wartosc);
        }




        public int Pop()
        {
            int wartosc = this.lista[0];
            this.lista.RemoveAt(0);
            return wartosc;
        }

        public void Push(int wartosc)
        {
            this.lista.Add(wartosc);
        }
    }
    class Stos : IAisd
    {
        public List<int> lista;
        public Stos(int wartosc)
        {
            this.lista = new List<int>();
            Push(wartosc);
        }



        public int Pop()
        {
            int wartosc = this.lista[this.lista.Count-1];
            this.lista.RemoveAt(this.lista.Count - 1);
            return wartosc;
        }

        public void Push(int wartosc)
        {
            this.lista.Add(wartosc);
        }
    }
    interface IAisd
    {
        void Push (int wartosc);
        int Pop();
    }
}
