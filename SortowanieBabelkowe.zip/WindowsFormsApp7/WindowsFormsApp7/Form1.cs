﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnZgadnijCo_Click(object sender, EventArgs e)
        {
            int[] cyfry = Konwertuj(tbCyfry.Text);
            int[] wynik = SortowanieB(cyfry);
            lbWynik.Text = string.Join(" ", wynik.ToArray());

        }

        private void btnZgadnijCo_MouseEnter(object sender, EventArgs e)
        {
        }

        private void btnZgadnijCo_MouseLeave(object sender, EventArgs e)
        {
        }

        int[] Konwertuj(string cyfry)
        {
            var wynikS = cyfry.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

            int[] wynik = new int[wynikS.Length];
            for (int i = 0; i < wynikS.Length; i++)
            {
                wynik[i] = int.Parse(wynikS[i].Trim());
            }

            return wynik;
        }
        
        int[] SortowanieB(int[] tab)
        {
            bool czyZamiana = false;

            do
            {
                czyZamiana = false;
                for (int i = 0; i < tab.Length - 1; i++)
                {
                    if (tab[i] > tab[i + 1])
                    {
                        var tmp = tab[i];
                        tab[i] = tab[i + 1];
                        tab[i + 1] = tmp;
                        czyZamiana = true;
                    }
                }
            } while (czyZamiana);

            return tab;
        }

        private void bw_DoWork(object sender, DoWorkEventArgs e)
        {
            int[] tab = e.Argument as int[];
            int licznik = 0;
            bool czyZamiana = false;
            do
            {

                czyZamiana = false;
                for (int i = 0; i < tab.Length - 1; i++)
                {
                    if (tab[i] > tab[i + 1])
                    {
                        var tmp = tab[i];
                        tab[i] = tab[i + 1];
                        tab[i + 1] = tmp;
                        czyZamiana = true;
                    }
                }
                licznik++;
            } while (czyZamiana);
            e.Result = tab;
        }
        private void bw_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            int[] cyfry = e.Result as int[];
            tbCyfry.Text = string.Join(" ", cyfry);
        }

        private void tbCyfry_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
