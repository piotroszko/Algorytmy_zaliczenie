﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuickSort
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> cos = new List<int>();

            var rand = new Random();

            for (int i = 0; i < 10; i++)
            {
                cos.Add(rand.Next(1000));
            }
            Console.WriteLine("Lista przed sortowaniem: ");

            foreach(int i in cos)
            {
                Console.Write(i + ", ");
            }
            QuickSort cosQ = new QuickSort(cos);

            cosQ.Sortuj(0, cos.Count - 1);
            Console.WriteLine("  ");
            Console.WriteLine("Lista po sortowaniu: ");
            foreach (int i in cosQ.lista)
            {
                Console.Write(i + ", ");
            }

            Console.ReadLine();
        }
    }
    class QuickSort
    {
        public List<int> lista;

        public QuickSort(List<int> lista)
        {
            this.lista = lista;
        }
        public void Sortuj (int lewo, int prawo)
        {
            int i = lewo;
            int j = prawo;
            int punkt = lista[(lewo + prawo) / 2];
            while (i<j)
            {
                while (lista[i] < punkt) i++;
                while (lista[j] > punkt) j--;
                if (i <= j)
                {
                    int tmp = lista[i];
                    lista[i++] = lista[j];
                    lista[j--] = tmp;
                }
            }
            if (i < j) Sortuj( lewo, j);
            if (i < prawo) Sortuj(i, prawo);

        }
    }
}
